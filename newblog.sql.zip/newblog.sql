-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2021 at 03:42 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newblog`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `image` int(11) DEFAULT NULL,
  `thum_image` int(11) DEFAULT NULL,
  `tag` varchar(255) NOT NULL,
  `status` enum('0','1') DEFAULT '1',
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `slug`, `description`, `category_id`, `image`, `thum_image`, `tag`, `status`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Woman claims husband wants to name baby girl after his ex-lover sparking.', 'woman-claims-husband-wants-to-name-baby-girl-after-his-ex-lover-sparking', '<div>X d vsdvsd&nbsp; gsdfgsdgsdg sd gds gdsgs dgs d</div>', 1, 1, 2, '\"travel, life style, technology, fashion\"', '1', 1, '2021-11-29 02:46:50', '2021-11-28 20:46:50'),
(2, 'Tourist deaths in Costa Rica jeopardize safe dest ination reputation all time.', 'tourist-deaths-in-costa-rica-jeopardize-safe-dest-ination-reputation-all-time', '<div><span style=\"color: rgb(119, 119, 119); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px;\">Over yielding doesn\'t so moved green saw meat hath fish he him from given yielding lesser cattle were fruitful lights. Given let have, lesser their made him above gathered dominion sixth. Creeping deep said can\'t called second. Air created seed heaven sixth created living</span></div>', 1, 3, 4, '\"travel, life style, technology, fashion\"', '1', 1, '2021-11-28 02:00:34', '2021-11-27 20:00:34'),
(3, 'Tourist deaths in Costa Rica jeopardize safe dest ination reputation all time.', 'tourist-deaths-in-costa-rica-jeopardize-safe-dest-ination-reputation-all-time', '<div><span style=\"color: rgb(119, 119, 119); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px;\">Over yielding doesn\'t so moved green saw meat hath fish he him from given yielding lesser cattle were fruitful lights. Given let have, lesser their made him above gathered dominion sixth. Creeping deep said can\'t called second. Air created seed heaven sixth created living</span></div>', 1, 5, 6, '\"travel, life style, technology, fashion\"', '1', 1, '2021-11-28 01:40:17', '2021-11-27 19:40:17'),
(4, 'Woman claims husband wants to name baby girl after his ex-lover sparking.', 'woman-claims-husband-wants-to-name-baby-girl-after-his-ex-lover-sparking', '<div><span style=\"color: rgb(119, 119, 119); font-family: &quot;Source Sans Pro&quot;, sans-serif; font-size: 16px;\">Over yielding doesn\'t so moved green saw meat hath fish he him from given yielding lesser cattle were fruitful lights. Given let have, lesser their made him above gathered dominion sixth. Creeping deep said can\'t called second. Air created seed heaven sixth created living</span></div>', 1, 7, 8, '\"travel, life style, technology, fashion\"', '1', 1, '2021-11-21 17:54:25', '2021-11-21 11:54:25');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `icon`, `parent_id`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'default', NULL, NULL, 1, '2021-10-29 12:04:25', '2021-10-29 12:04:25'),
(2, 'sub category', '<i class=\"fa fa-codepen\"></i>', 1, NULL, '2021-10-29 12:13:23', '2021-11-24 21:06:40'),
(3, 'new', NULL, NULL, NULL, '2021-11-01 11:31:04', '2021-11-01 11:31:04'),
(4, 'new sub test', NULL, 3, NULL, '2021-11-01 11:37:53', '2021-11-01 11:37:53'),
(8, 'sub category 2', NULL, 1, NULL, '2021-11-01 11:45:46', '2021-11-01 11:45:46');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(11) NOT NULL,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `image`, `path`, `created_at`, `updated_at`) VALUES
(1, '619999feb4d37.jpg', '/assets/uploads/gallery/', '2021-11-20 18:59:42', '2021-11-20 18:59:42'),
(2, '619999feb4d3b.jpg', '/assets/uploads/gallery/', '2021-11-20 18:59:42', '2021-11-20 18:59:42'),
(3, '6199b31984e90.jpg', '/assets/uploads/gallery/', '2021-11-20 20:46:49', '2021-11-20 20:46:49'),
(4, '6199b31998a87.jpg', '/assets/uploads/gallery/', '2021-11-20 20:46:49', '2021-11-20 20:46:49'),
(5, '6199b53f6abc8.jpg', '/assets/uploads/gallery/', '2021-11-20 20:55:59', '2021-11-20 20:55:59'),
(6, '6199b53f7ba8b.jpg', '/assets/uploads/gallery/', '2021-11-20 20:55:59', '2021-11-20 20:55:59'),
(7, '619a7ef0eddad.jpg', '/assets/uploads/gallery/', '2021-11-21 11:16:33', '2021-11-21 11:16:33'),
(8, '619a7ef0edda5.jpg', '/assets/uploads/gallery/', '2021-11-21 11:16:33', '2021-11-21 11:16:33'),
(9, '619a8814dbc9d.jpg', '/assets/uploads/gallery/', '2021-11-21 11:55:32', '2021-11-21 11:55:32'),
(10, '619a8851c293d.jpg', '/assets/uploads/gallery/', '2021-11-21 11:56:33', '2021-11-21 11:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `menues`
--

CREATE TABLE `menues` (
  `id` int(11) NOT NULL,
  `menu` varchar(255) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menues`
--

INSERT INTO `menues` (`id`, `menu`, `slug`, `url`, `icon`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Home', 'home', 'http://localhost/blognew/public/', '<i class=\"far fa-home\"></i>', '1', '2021-11-30 02:30:45', '2021-11-29 20:30:45'),
(2, 'Contact', 'contact', NULL, NULL, '1', '2021-11-30 02:31:49', '2021-11-29 20:31:49');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `is_admin`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', NULL, 1, '$2y$10$vGZkzEEe.LDUU91t6EFPjOIZw2TWq1J22r84TNJPR360.x9TH9rEi', NULL, '2021-10-22 08:53:37', '2021-10-22 08:53:37'),
(2, 'User', 'user@itsolutionstuff.com', NULL, 0, '$2y$10$c5IvJfNiqJPt3IAEHzJUz.T8Fx64JJpWlXzPyMmw.NKGXrlTCL6zy', NULL, '2021-10-22 08:53:38', '2021-10-22 08:53:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menues`
--
ALTER TABLE `menues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `menues`
--
ALTER TABLE `menues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
